package com.example.event2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Create a LinearLayout as the root layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        // Create a TextView
        TextView textView = new TextView(this);
        textView.setText("Creating UI elements using Java");
        layout.addView(textView);

        // Create a Button
        Button button = new Button(this);
        button.setText("Click Me");
        layout.addView(button);

        // Create a RadioGroup with two RadioButtons
        final RadioGroup radioGroup = new RadioGroup(this);
        RadioButton radioButton1 = new RadioButton(this);
        radioButton1.setText("Radio Button 1");
        radioButton1.setId(View.generateViewId()); // Set a unique ID
        RadioButton radioButton2 = new RadioButton(this);
        radioButton2.setText("Radio Button 2");
        radioButton2.setId(View.generateViewId()); // Set a unique ID
        radioGroup.addView(radioButton1);
        radioGroup.addView(radioButton2);
        layout.addView(radioGroup);

        // Create an EditText
        final EditText editText = new EditText(this); // Made final to be accessible in the listener
        editText.setHint("Enter text here");
        layout.addView(editText);

        // Set the layout as the content view
        setContentView(layout);

        // Set an OnClickListener for the button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the text from the EditText
                String enteredText = editText.getText().toString();

                // Get the ID of the selected radio button
                int selectedId = radioGroup.getCheckedRadioButtonId();

                // Check if a radio button is selected
                if (selectedId != -1) {
                    // Find the radio button by its ID
                    RadioButton selectedRadioButton = findViewById(selectedId);

                    // Create the message string
                    String message = enteredText + " " + selectedRadioButton.getText() + " is chosen";

                    // Display a Toast message with the combined text
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                } else {
                    // Display a Toast message if no radio button is selected
                    Toast.makeText(MainActivity.this, "No radio button is chosen", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
